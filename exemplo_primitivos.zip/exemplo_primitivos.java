import java.util.Scanner;

class exemplo_primitivos {

    public static void main(String[] args) {

    int exinteiro;
    char exchar;
    double exdouble ;
    boolean exboolean;
    String exString;
        
     Scanner s = new Scanner(System.in);

     System.out.print("Informe os valores de:");
    exinteiro = s.nextInt();
    System.out.println("Seu Valor é: "+exinteiro);

    System.out.println("Informe uma letra:");
    exchar =  s.next().charAt(0);
    System.out.print("Sua letra é:"+exchar);
    
        
    }
    
}
