import java.util.Scanner;


public class matricula {
    
    public static void main (String[] args){

        int matricula;
        double num_horas, valor_hora, valor_hora_extra, num_horas_extras, salario_normal, salario_extra, salario_total;
        String mes;

        Scanner s = new Scanner (System.in);
        salario_extra = 0;
        num_horas_extras = 0;
        salario_normal = 0;

        System.out.println("Programa para calcular salario");
        System.out.print("Matricula:");
        matricula = s.nextInt();
        System.out.print("Valor da hora:");
        valor_hora = s.nextDouble();
        System.out.print("Horas trabalhadas:");
        num_horas = s.nextDouble();
        System.out.print("Mês de referencia:");
        mes = s.nextLine();

        if(num_horas > 200){
            num_horas_extras = num_horas - 200;
            valor_hora_extra = valor_hora * 1.5;
            salario_extra = num_horas_extras * valor_hora_extra;
        }

        salario_extra = num_horas * valor_hora;
        salario_total = salario_normal + salario_extra;

        System.out.println("resultado do calculo: ");
        System.out.println("Matricula: " + matricula);
        System.out.println("Total de horas trabalhadas: " + num_horas);
        System.out.println("Total de horas extras: " + num_horas_extras);
        System.out.println("valor salario normal : " + salario_normal);
        System.out.println( "valor salario extra:" + salario_extra);
        System.out.println("Salario total: " + salario_total);

        
        s.close();
    }
    
    
}