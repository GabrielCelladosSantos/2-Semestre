import java.util.Scanner;

public class peso {
    
        public static void main (String [] args){
            
            double altura;
            double peso;
            char sexo;
            double pesoideal = 0;
            
            Scanner s = new Scanner (System.in);

            System.out.println("Qual sua Altura:");
            altura = s.nextDouble();

            System.out.println("Qual seu Peso:");
            peso = s.nextDouble();

            System.out.println("Qual seu sexo:");
            sexo = s.next().charAt(0);

            if( sexo == 'M'){
                pesoideal = (72.7 * altura) - 58 ;
            } else if( sexo == 'F'){
                pesoideal = ( 62.1 * altura) - 44.7;
            
            }else {
                
                System.out.println("Opção de sexo inválida. Use M ou F.");
                s.close();
                return;
            }
            System.out.printf("Seu peso ideal é: %.2f kg%n", pesoideal);
            if (peso < pesoideal){
                System.out.println("Resultado:Você está abaixo do peso ideal") ;
            }else if ( peso > pesoideal){
                System.out.println("Resultado:Você está acima do peso ideal");
            }else {
                System.out.println("Resultado: Parabens você está no peso ideal.");
            }
            
        s.close();
        
        }
}
