
import java.util.Scanner;

public class nascimento {
    public static void main (String [] args){

    int nascimento;
    int anoatual = 2025;
    int idade;

        Scanner s = new Scanner (System.in);

        System.out.print("Qual ano você nasceu: ");
        nascimento = s.nextInt();

        idade = anoatual - nascimento;

        System.out.print("Sua idade é: " + idade + " anos.");

        if ( idade >= 18){
            System.out.print("Você pode votar e tirar habilitação");
        }else if ( idade >= 16){
            System.out.print("Você pode votar mais não pode tirar habilitação");
        }else{            System.out.print("Você ainda não pode votar e nem tirar habilitação");
        }
    System.out.println("");
        s.close();
    }
}
