import java.util.Scanner;

public class crescente {
    

public static void main(String[] args){
    
    Scanner s = new Scanner(System.in);

    //Solicitar e ler os três valores.
    System.out.println("Digite três valores inteiros e diferentes: ");
    System.out.print("Primeiro valor: ");
    int valor1 = s.nextInt();

    System.out.print("Segundo valor: ");
    int valor2 = s.nextInt();

    System.out.print("Terceriro valor: ");
    int valor3 = s.nextInt();

    System.out.print("-------------------------------------");

    // Verificar extra: garante que são diferentes numero.

    if ( valor1 == valor2 ||  valor1 == valor3 || valor2 == valor3){
        System.out.println("Erro: Os valores digitados devem ser diferentes");
    } else{
        //descobrir qual dos três e o maior numero.
// caso valor 1 seja o menor
        if( valor1 < valor2 && valor1 < valor3  ){
if (valor2 < valor3){
    System.out.println("A ordem crescente é : " + valor1 +"," + valor2 + "," + valor3);

}else{
    System.out.println("A ordem crescente é: " + valor1 + ", " + valor3 + ", " + valor2);
}
}
// Caso 2: v2 é o menor de todos.
else if (valor2 < valor1 && valor2 < valor3) {
// Agora, só precisamos saber a ordem entre v1 e v3.
if (valor1 < valor3) {
    System.out.println("A ordem crescente é: " + valor2 + ", " + valor1 + ", " + valor3);
} else {
    System.out.println("A ordem crescente é: " + valor2 + ", " + valor3 + ", " + valor1);
}
}
// Caso 3: Se nem v1 nem v2 são os menores, então v3 tem que ser o menor.
else {
// Agora, só precisamos saber a ordem entre v1 e v2.
if (valor1 < valor2) {
    System.out.println("A ordem crescente é: " + valor3 + ", " + valor1 + ", " + valor2);
} else {
    System.out.println("A ordem crescente é: " +valor3 + ", " + valor2 + ", " + valor1);
}
}
}

// Fecha o scanner para liberar recursos.
s.close();
}
}
