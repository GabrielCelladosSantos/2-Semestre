import java.util.Scanner;

public class Mês {
    public static void main ( String []args ){
        
        int mes;

        Scanner s = new Scanner(System.in);

        System.out.println("Numero do Mês que voçe se encontra: ");
        mes =s.nextInt();

        if( mes < 1 ){

            System.out.println("Numero invalido" );
        }else if (mes > 12){
            System.out.println("numero invalido");
        }
    }
}
