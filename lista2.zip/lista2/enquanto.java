public class enquanto {
    
    public static void main(String [] args){
 
    int cont;
    cont= 67;

    while (cont < 73) {
        System.out.println("Contador: " + cont);

        //cont++;
        cont = cont + 1;
    }
 
     System.out.println("Exemplo  com repita (Do):");
    cont = 67;

    do { 
      System.out.println("Contador: " + cont);
      cont++;  
    } while (cont < 73) ;

        System.out.println("Exemplo para (for): " );
    for (int i=67; i < 73; i++ ){    
        System.out.println("Contador: " + i);

    }
}



}

