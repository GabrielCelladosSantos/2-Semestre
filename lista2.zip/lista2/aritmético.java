import java.util.Scanner;
public class aritmético {
    public static void main (String[]args){
        
        double valor1;
        double valor2;
        char operador;
        double resultado;


        Scanner s = new Scanner (System.in);

        System.out.print("Qual seu valor 1 : ");
        valor1 = s.nextDouble();

        System.out.print("Qual o valor 2:");
        valor2 = s.nextDouble();

        System.out.print("Qual o operador:");
        operador = s.next(). charAt(0);

if( operador == '+'){
    resultado = valor1 + valor2;
    System.out.println("A soma foi de: " + valor1 + "+" + valor2 + "=" + resultado);
}else if ( operador == '-'){
    resultado = valor1 - valor2;
    System.out.println("A subtração foi de:" + valor1 + "-" + valor2 + "=" + resultado);
}else if (operador == '*'){
    resultado = valor1 * valor2;
    System.out.println("A mutiplicação foi de:" + valor1 + "*" + valor2 + "=" + resultado );
}else if (operador == '/'){
    if (valor2 == 0){
        System.out.println("Erro: Divisão por zero não existe");
    }else{
        resultado = valor1 / valor2;
        System.out.println("");
    }
}
    }
}
