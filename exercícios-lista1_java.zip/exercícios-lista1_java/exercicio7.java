
import java.util.Scanner;

public class exercicio7 {
    public static void main(String[] args){
        int num1, num2;
        Scanner s = new Scanner(System.in);

        System.out.print("Informe o primeiro numero");
        num1 = s.nextInt();
        System.out.print("informe o segundo numero");
        num2 = s.nextInt();

        System.out.println("Resultado das comparações entre os numero informados:");
        System.out.println("num1 > num2: " + (num1 > num2));
        System.out.println("num1 < num2: " + ( num1 < num2));
        System.out.println("num1 == num2: " + (num1 == num2));
        System.out.println("num1 != num2: "  + (num1 != num2));
        }
}
