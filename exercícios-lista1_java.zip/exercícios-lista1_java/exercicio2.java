import  java.util.Scanner;

public class exercicio2{

    public static void main(String[] args) {
        
        String nome;
        int idade;
        char Gênero;
        String Cor_favorita;
        boolean Esporte_praticado;
        String Carro;

        Scanner scanner = new Scanner(System.in);
        System.out.println("Bem-Vindo ao campus 3");
        System.out.println("Responda as perguntas abaixo");

        System.out.print("Qual seu nome:");
        nome = scanner.nextLine();

        System.out.print("Qual sua idade:");
        idade = scanner.nextInt();

        System.out.print("Qual seu gênero:");
        Gênero= scanner.next().charAt(0);

        System.out.print("Qual sua cor favorita minha flor:");
        Cor_favorita = scanner.nextLine();

        System.out.print("Você pratica esporte Sim/Não? se sim qual:");
        Esporte_praticado = scanner.nextBoolean();

        System.out.print("Qual seu carro?");
        Carro = scanner.nextLine();

        System.out.println("Informações digitadas ---");
        System.out.println("Nome " + nome );
        System.out.println("Idade " + idade);
        System.out.println("Gênero " + Gênero );
        System.out.println("Cor_favorita "  + Cor_favorita );
        System.out.println("Esporte_praticado " + Esporte_praticado);
        System.out.println("Carro " + Carro);

        scanner.close ();


    }
}


    

