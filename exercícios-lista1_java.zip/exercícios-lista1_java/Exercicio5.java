
import java.util.Scanner;

public class Exercicio5 {
    public  static void main (String[] args){
        int num;
        Scanner s = new Scanner (System.in);
        String resultado = "Numero Par";

        System.out.print("Informe o primeiro numero:");
        num = s.nextInt();

        if( num % 2 ==0){
            System.out.println("Numero PAR");
            }
            else {
            System.out.println("numero IMPAR");
            }
    }
}
