import java.util.Scanner;

public class exercicio3 {

    public static void main(String[] args) {
        

        int num1 ;
        int num2 ;

        Scanner s = new Scanner (System.in) ;
        
        System.out.println("Informe o primeiro numero:");
        num1 = s.nextInt();

        System.out.println("Informe o segundo numero");
        num2 = s.nextInt();

        System.out.print("O Resultado da Soma dos dois numeros é: "+(num1 + num2)+"\n"+"O Resultado da subtracao é: "+(num1-num2)+ "\n"+ "O resultado da multiplicacao:"+(num1 * num2)+"\n"+"O resultado da divisao:"+(num1 / num2));

    }
    
}
