import java.util.Scanner;

public class exercicio1{

    public static void main(String[] args) {
        
    int bimestre1 ; 
    int bimestre2 ;
    int semestre ;

    Scanner scanner = new Scanner (System.in);
        
    
    System.out.print("Informe a nota do primeiro bimestre:");
    bimestre1 = scanner.nextInt();

    System.out.print("Informe a nota do segundo bimestre");
    bimestre2= scanner.nextInt();

    semestre = (bimestre1 + bimestre2) / 2;

    if (semestre >= 6) {System.out.print("Aprovado");}
    else if (semestre >= 4) {System.out.print("Precisa de prova substitutiva");}
    else {System.out.print("Reprovado");}
    }
    
}
